<?php

return [
    'Id'  =>  'ID',
    'Name'  =>  '运费模版名称',
    'Method'  =>  '计费方式',
    'Method 10'  =>  '按件数',
    'Method 20'  =>  '按重量',
    'Weigh'  =>  '权重',
    'Createtime'  =>  '创建时间',
    'Updatetime'  =>  '更新时间'
];
