<?php

return [
    'Id'  =>  'ID',
    'Pid'  =>  '父ID',
    'Name'  =>  '分类名称',
    'Image'  =>  '图片',
    'Weigh'  =>  '权重',
    'Createtime'  =>  '创建时间',
    'Updatetime'  =>  '更新时间'
];
